# Definition of Done

## Cowork-native feature

A Cowork-native change is done when:

- implementation is complete;
- applicable tests pass;
- documentation is updated when needed;
- the Pull Request is reviewed;
- the change is merged into the stable/default branch.

## Core AI contribution

A Core AI contribution is done only when its Pull Request is merged into Cowork Local. “Core AI finished coding” or “Core AI pre-review passed” is not Done.

Required evidence:

- Core issue reference;
- Cowork Local Pull Request;
- test/validation evidence;
- Cowork reviewer;
- merge commit or merge reference.

Use one logical change per Pull Request. For example, TL-065, TL-146, and TL-148 Phase 1 require separate Pull Requests. Split large work into vertical, reviewable slices.
