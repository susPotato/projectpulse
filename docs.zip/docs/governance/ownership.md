# Repository Ownership

## Cowork Team

The Cowork Team owns:

- product architecture;
- Cowork runtime and platform behavior;
- UI/UX;
- releases;
- the stable/default branch;
- final Pull Request review and merge.

## FSG AI Core Team

The AI Core Team contributes selected generic capabilities, including:

- MCP integrations;
- agent capabilities;
- orchestration tests;
- model-routing and fallback tests;
- security/evaluation integration;
- Superpowers enhancements;
- reusable platform improvements.

AI Core is a contributor, not the owner of Cowork Local. It does not self-merge a contribution into the Cowork production branch before Cowork Team review.

`OWNERS.yaml` records team-level ownership only. It intentionally contains no invented usernames and does not assume GitHub CODEOWNERS semantics in Gitea.
